package com.akudama.test;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 48, 48, 48);
        root.setBackgroundColor(Color.rgb(12, 16, 25));
        TextView title = new TextView(this);
        title.setText("AKUDAMA BUILDER");
        title.setTextSize(27);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView status = new TextView(this);
        status.setText("Первый APK успешно установлен!");
        status.setTextColor(Color.rgb(138, 209, 255));
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 36, 0, 36);
        root.addView(status);
        Button button = new Button(this);
        button.setText("Проверить");
        button.setOnClickListener(v -> status.setText("Работает! Теперь можно собирать свои приложения."));
        root.addView(button);
        setContentView(root);
    }
}
